# sachin v virat
# this comparison is between there all over datas in perticular period of time that is metioned bellow -

#-----------------------------------------------------------------------------------------------------------------------

#######             getting the data-


#importing requierd files-
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt

#to display rows and collumns-
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.expand_frame_repr', False)
pd.set_option('max_colwidth', -1)


df=pd.read_csv('ODI_data.csv')
print(df.head(2))
print("\n")
print(len(df))

print(df['Innings Runs Scored Num'].unique())
print("\n")
#so we have to remove the '-' to ge the  data to work on-
df=df[df['Innings Runs Scored Num'] !='-']
print(df['Innings Runs Scored Num'].unique())
print("\n")

#now we have to remove the command from the date to ge the  data to work on-
df=df.dropna(subset=['Innings Runs Scored Num'])
print(df['Innings Runs Scored Num'].unique())
print("\n")
print(df.head(1))
print("\n")

#convert to date time-
df['Innings Date']=pd.to_datetime(df['Innings Date'])
#adding year to data frame frome innings date
df['year']=df['Innings Date'].dt.year
print(df.tail(1))
print("\n")

#first we get the data types -
print(df.dtypes)
print('\n')
#so we have to first convert the data types of Innings Runs Scored Num , Innings Balls Faced & Innings Not Out Flag  into intiger data type
# we don'nt have to convert the data types of 50's & 100's because they are already in float data type
df['Innings Runs Scored Num']=df['Innings Runs Scored Num'].astype('int')
df['Innings Balls Faced']=df['Innings Balls Faced'].astype('int')
df['Innings Not Out Flag']=df['Innings Not Out Flag'].astype('int')
print(df.dtypes)
print('\n')


#sachin first centur is -1994
#virat first century is -2009
#so now we have to compare their data i.e
# sachin -1994-2004
# virat -2009-2019
# so that is 11 years of datas
sachin_df=df[(df.year >=1994) & (df.year <=2004) ]
virat_df=df[(df.year >=2009) & (df.year <=2019) ]
print(sachin_df.head(2)) #this is sachin data frame with other players in that time line
print("\n")
print(virat_df.head(2)) #this is virat data frame with other players in that time line
print("\n")

#-----------------------------------------------------------------------------------------------------------------------



####               pre-processing the datas -




#what is the total runs scored by scahin in this time phrase -
print(sachin_df.head(20))
print("\n")
# to get the sachin's data we have to
sdf=sachin_df[sachin_df['Innings Player']=='SR Tendulkar'] #sachin data frame - this is sachin data frame without other players in that time line
print(sdf.head())
print("\n")
# total runs scored by scahin-
total_runs_scored_by_scahin=sum(sdf['Innings Runs Scored Num'])
print(total_runs_scored_by_scahin)
print("\n")

#what is the total runs scored by virat in this time phrase -
print(virat_df.head(20))
print("\n")
# to get the virat's data we have to
vdf=virat_df[virat_df['Innings Player']=='V Kohli'] #virat data frame - this is virat data frame without other players in that time line
print(vdf.head())
print("\n")
# # total runs scored by virat-
total_runs_scored_by_virat=sum(vdf['Innings Runs Scored Num'])
print(total_runs_scored_by_virat)
print("\n")
# kohli_df['Innings Player'].unique() #to get the player name



# Runs per innings = Total Runs/Total Innings
# SR = 100*(Total Runs/Total Balls)
# 100's = sum(100's)
# 50's = sum(50's)
# Team contribution = Player Runs/Team Runs (ex: Virat 50/ Team Ind 150 => 50/150 : 33%)


#to get run per innings of virat and sachin
#first we have total runs scored and to get Total Innings we have to just get the lenght of their data frame i.e total innings will be total number of rows
tis = len(sdf)#total innings of sachin
tiv = len(vdf)#total innings of virat
# Runs per innings = Total Runs/Total Innings-
print("Runs per innings of virat-",end=" ")
rpi_virat=total_runs_scored_by_virat/tiv
print(rpi_virat)
print("Runs per innings of sachin-",end=" ")
rpi_sachin=total_runs_scored_by_scahin/tis
print(rpi_sachin,"\n")

# SR = 100*(Total Runs/Total Balls)
#to find the total ball faced
total_balls_faced_by_sachin=sum(sdf['Innings Balls Faced'])
total_balls_faced_by_virat=sum(vdf['Innings Balls Faced'])
print("SR of sachin -",end=" ")
SR_of_sachin=100*(total_runs_scored_by_scahin/total_balls_faced_by_sachin)
print(SR_of_sachin)
print(f"SR of virat -",end=" ")
SR_of_virat=100*(total_runs_scored_by_virat/total_balls_faced_by_virat)
print(SR_of_virat,"\n")

#100's
print("100's of sachin-",end=" ")
sachin100=sum(sdf["100's"])
print(sachin100)
print("100's of virat-",end=" ")
virat100=sum(vdf["100's"])
print(virat100,"\n")

#50's
print("50's of sachin-",end=" ")
sachin50=sum(sdf["50's"])
print(sachin50)
print("50's of virat-",end=" ")
virat50=sum(vdf["50's"])
print(virat50,"\n")

# # Team contribution = Player Runs/Team Runs (ex: Virat 50/ Team Ind 150 => 50/150 : 33%)
# total_runs_india_at_sachin_timeline=sum(sachin_df[sachin_df['Country']=='India']['Innings Runs Scored Num'])
# total_runs_india_at_virat_timeline=sum(virat_df[virat_df['Country']=='India']['Innings Runs Scored Num'])
# print("team contribution of sachin- ")
# team_contribution_of_sachin=100*(total_runs_scored_by_scahin/total_runs_india_at_sachin_timeline)
# print(team_contribution_of_sachin," %")
# print(f"team contribution of virat- ")
# team_contribution_of_virat=100*(total_runs_scored_by_virat/total_runs_india_at_virat_timeline)
# print(team_contribution_of_virat," %\n")

#-----------------------------------------------------------------------------------------------------------------------


#######################         visualizations-

#now i want to see how many other players has scored total runs in sachin's time line-
print(sachin_df.groupby('Innings Player')['Innings Runs Scored Num'].sum().sort_values(ascending=False))
sachin_df.groupby('Innings Player')['Innings Runs Scored Num'].sum().sort_values(ascending=False).head(10).plot(kind='barh') #i have taken out of 10 by taking head 10 and barh means horizontal bar graph
plt.show()
print("\n")
#now i want to see how many other players has scored total runs in virat's time line-
print(virat_df.groupby('Innings Player')['Innings Runs Scored Num'].sum().sort_values(ascending=False))
virat_df.groupby('Innings Player')['Innings Runs Scored Num'].sum().sort_values(ascending=False).head(10).plot(kind='barh')
plt.show()
print("\n")

#now i want to see the sachin's progress over the year -
print(sdf.groupby('year')['Innings Runs Scored Num'].sum())
print(sdf.groupby('year')['Innings Runs Scored Num'].sum().plot(kind='bar'))
plt.show()
print("\n")

#now i want to see the virat's progress over the year -
print(vdf.groupby('year')['Innings Runs Scored Num'].sum())
print(vdf.groupby('year')['Innings Runs Scored Num'].sum().plot(kind='bar'))
plt.show()
print("\n")

#normalization-

#players excluding sachin
not_sachin_df=sachin_df[sachin_df['Innings Player']!='SR Tendulkar']
# rpi without sachin at sachin's time line-
avg_not_sachin=sum(not_sachin_df['Innings Runs Scored Num'])/len(not_sachin_df)
print(f"avg runs without sachin at sachin's timeline- {avg_not_sachin}")


#players excluding kholi
not_virat_df=virat_df[virat_df['Innings Player']!='V Kohli']
# avg runs without virat at  virat's time line-
avg_not_virat=sum(not_virat_df['Innings Runs Scored Num'])/len(not_virat_df)
print(f"avg runs without virat at  virat's timeline- {avg_not_virat}\n")

#-----------------------------------------------------------------------------------------------------------------------



######           conclusion of the case study-

print("----------------------------------------------------------conclusion-------------------------------------------------------------------------")


# final rpi -
#how much time is sachin better than other oalyers at that timeline-
bettersachin=rpi_sachin/avg_not_sachin
print(f"final rpi - sachin was {bettersachin} times better than the rest of the players at that generation")
#how much time is virat better than other oalyers at that timeline-
bettervirat=rpi_virat/avg_not_virat
print(f"final rpi- virat is {bettervirat} times better than the rest of the players at this generation")
print("winner-virat\n")

# final SR = 100*(Total Runs/Total Balls)
total_balls_faced_by_notsachin=sum(not_sachin_df['Innings Balls Faced'])
not_SR_sachin=100*((sum(not_sachin_df['Innings Runs Scored Num']))/total_balls_faced_by_notsachin)
finalsachinsr=SR_of_sachin/not_SR_sachin
print(f"total strike rate of sachin is - {finalsachinsr}")
total_balls_faced_by_notvirat=sum(not_virat_df['Innings Balls Faced'])
not_SR_virat=100*((sum(not_virat_df['Innings Runs Scored Num']))/total_balls_faced_by_notvirat)
finalviratsr=SR_of_virat/not_SR_virat
print(f"total strike rate of virat is - {finalviratsr}")
print("winner-sachin\n")

# normalized_100_value- always remember here less the number is the winner becase if it is less means he needs less match to score a 100
sachin_matches_per_100=len(sdf)/sum(sdf["100's"])
sachin_peers_matches_per_100 = len(not_sachin_df)/sum(not_sachin_df["100's"])
normalized_sachin100_value=sachin_matches_per_100/sachin_peers_matches_per_100
print(f"normalized_sachin100_value - {normalized_sachin100_value}")

virat_matches_per_100=len(vdf)/sum(vdf["100's"])
virat_peers_matches_per_100 = len(not_virat_df)/sum(not_virat_df["100's"])
normalized_virat100_value=virat_matches_per_100/virat_peers_matches_per_100
print(f"normalized_virat100_value - {normalized_virat100_value}")
print("winner-sachin\n")

# normalized_50_value-remember here less the number is the winner becase if it is less means he needs less match to score a 50
sachin_matches_per_50=len(sdf)/sum(sdf["50's"])
sachin_peers_matches_per_50 = len(not_sachin_df)/sum(not_sachin_df["50's"])
normalized_sachin50_value=sachin_matches_per_50/sachin_peers_matches_per_50
print(f"normalized_sachin50_value - {normalized_sachin50_value}")

virat_matches_per_50=len(vdf)/sum(vdf["50's"])
virat_peers_matches_per_50 = len(not_virat_df)/sum(not_virat_df["50's"])
normalized_virat50_value=virat_matches_per_50/virat_peers_matches_per_50
print(f"normalized_virat50_value - {normalized_virat50_value}")
print("winner-virat\n")

# Team contribution = Player Runs/Team Runs (ex: Virat 50/ Team Ind 150 => 50/150 : 33%)
total_runs_india_at_sachin_timeline=sum(sachin_df[sachin_df['Country']=='India']['Innings Runs Scored Num'])
total_runs_india_at_virat_timeline=sum(virat_df[virat_df['Country']=='India']['Innings Runs Scored Num'])
print("team contribution of sachin-",end=" ")
team_contribution_of_sachin=100*(total_runs_scored_by_scahin/total_runs_india_at_sachin_timeline)
print(team_contribution_of_sachin,"%")
print(f"team contribution of virat-",end=" ")
team_contribution_of_virat=100*(total_runs_scored_by_virat/total_runs_india_at_virat_timeline)
print(team_contribution_of_virat,"%")
print("winner-virat")
print("------------------------------------------------------------------------------------------------------------------------------------------------------")